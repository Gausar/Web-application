import React, { Component } from 'react';
import { AppBar, Toolbar, Typography, Button } from '@mui/material';
import { withRouter } from 'react-router-dom';
import axios from 'axios';
import './styles.css';

class TopBar extends Component {
  constructor(props) {
    super(props);
    this.state = {
      contextInfo: '',
      user: null,
    };
  }

  componentDidMount() {
    this.updateContextInfo();
    this.getUserInfo();
  }

  componentDidUpdate(prevProps) {
    if (prevProps.location.pathname !== this.props.location.pathname) {
      this.updateContextInfo();
    }
  }

  getUserInfo = () => {
    const user = JSON.parse(localStorage.getItem('user'));
    this.setState({ user });
  };

  updateContextInfo = async () => {
    const { pathname } = this.props.location;
    let newContextInfo = '';

    const userId = pathname.split('/')[2];

    if (pathname === '/users') {
      newContextInfo = 'All Users';
    } else if (pathname.startsWith('/users/')) {
      try {
        const response = await axios.get(`/users/${userId}`);
        const user = response.data;
        if (user) {
          newContextInfo = `Details of ${user.first_name} ${user.last_name}`;
        }
      } catch (error) {
        console.error('Error fetching user details:', error);
      }
    } else if (pathname.startsWith('/photos/')) {
      try {
        const response = await axios.get(`/users/${userId}`);
        const user = response.data;
        if (user) {
          newContextInfo = `Photos of ${user.first_name} ${user.last_name}`;
        }
      } catch (error) {
        console.error('Error fetching user details:', error);
      }
    }
    this.setState({ contextInfo: newContextInfo });
  };

  handleLogout = async () => {
    try {
      await axios.post('/admin/logout');
      localStorage.removeItem('user');
      this.setState({ user: null });
      this.props.history.push('/login');
    } catch (error) {
      console.error('Logout failed:', error);
    }
  };

  render() {
    const { contextInfo, user } = this.state;

    return (
      <AppBar className="cs142-topbar-appBar" position="absolute">
        <Toolbar className="cs142-topbar-toolbar">
          <div className="cs142-topbar-left">
            <img src="user.png" alt="User Logo" className="userLogo" />
            <Typography variant="h6" color="inherit">
              {contextInfo}
            </Typography>
          </div>
          <div className="toolbar-left">
            {user && (
              <Typography variant="h6" color="inherit">
                Hi {user.first_name}
              </Typography>
            )}
          </div>
          <div className="toolbar-right">
            {user ? (
              <Button 
                color="inherit" 
                onClick={this.handleLogout} 
                sx={{
                  border: '1px solid white',
                  borderRadius: '4px',
                  paddingX: '5px',
                }}
              >
                Logout
              </Button>
            ) : (
              <Typography 
                variant="h6" 
                color="inherit"
                sx={{
                  border: '1px solid white',
                  borderRadius: '4px',
                  paddingX: '5px',
                }}
              >
                Login
              </Typography>
            )}
          </div>
        </Toolbar>
      </AppBar>
    );
  }
}

export default withRouter(TopBar);
