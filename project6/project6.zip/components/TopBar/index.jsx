import React, { Component } from "react";
import { AppBar, Toolbar, Typography } from "@mui/material";
import { withRouter } from "react-router-dom";
import axios from "axios";
import "./styles.css";

class TopBar extends Component {
  constructor(props) {
    super(props);
    this.state = {
      contextInfo: "",
    };
  }

  componentDidMount() {
    this.updateContextInfo();
  }

  componentDidUpdate(prevProps) {
    if (prevProps.location.pathname !== this.props.location.pathname) {
      this.updateContextInfo();
    }
  }

  updateContextInfo = async () => {
    const { pathname } = this.props.location;
    let newContextInfo = "";

    const userId = pathname.split("/")[2];

    if (pathname === "/users") {
      newContextInfo = "All Users";
    } else if (pathname.startsWith("/users/") && userId) {
      try {
        const response = await axios.get(`/user/${userId}`);
        const user = response.data;
        if (user) {
          newContextInfo = `Details of ${user.first_name} ${user.last_name}`;
        }
      } catch (error) {
        console.error("Error fetching user details:", error);
      }
    } else if (pathname.startsWith("/photos/") && userId) {
      try {
        const response = await axios.get(`/user/${userId}`);
        const user = response.data;
        if (user) {
          newContextInfo = `Photos of ${user.first_name} ${user.last_name}`;
        }
      } catch (error) {
        console.error("Error fetching user details:", error);
      }
    }

    this.setState({ contextInfo: newContextInfo });
  };

  render() {
    const { contextInfo } = this.state;

    return (
      <AppBar className="cs142-topbar-appBar" position="absolute">
        <Toolbar>
          <img src="user.png" alt="User Logo" className="userLogo" />
          <Typography variant="h5" color="inherit" className="left"> Gausar </Typography>
          <Typography variant="h5" color="inherit" style={{ marginLeft: "auto" }}>{contextInfo}</Typography>
          <img src="signLogo.png" alt="Sign Logo" className="signLogo" />
        </Toolbar>
      </AppBar>
    );
  }
}

export default withRouter(TopBar);
