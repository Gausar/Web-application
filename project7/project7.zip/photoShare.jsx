// import React from "react";
// import ReactDOM from "react-dom";
// import { Grid, Typography, Paper } from "@mui/material";
// import { HashRouter, Route, Switch, Redirect } from "react-router-dom";
// import "./styles/main.css";
// import TopBar from "./components/TopBar";
// import UserDetail from "./components/UserDetail";
// import UserList from "./components/UserList";
// import UserPhotos from "./components/UserPhotos";
// import LoginRegister from "./components/loginRegister";
// class PhotoShare extends React.Component {
//   constructor(props) {
//     super(props);
//     this.state = {
//       advancedFeaturesEnabled: false,
//       user: JSON.parse(localStorage.getItem('user')),
//     };
//   }
//   setUser = (user) => {
//     this.setState({ user });
//   };
//   handleAdvancedFeaturesToggle = () => {
//     this.setState((prevState) => ({
//       advancedFeaturesEnabled: !prevState.advancedFeaturesEnabled,
//     }));
//   };
//   render() {
//     const { advancedFeaturesEnabled, user } = this.state;
//     return (
//       <HashRouter>
//         <div>
//           <Grid container spacing={2}>
//             <Grid item xs={12}>
//               <TopBar
//                 user={user}
//                 advancedFeaturesEnabled={advancedFeaturesEnabled}
//                 onAdvancedFeaturesToggle={this.handleAdvancedFeaturesToggle}
//                 setUser={this.setUser}
//               />
//             </Grid>
//             <div className="cs142-main-topbar-buffer" />
//             <Grid item sm={3}>
//               <Paper className="cs142-main-grid-item">
//                 {user && <UserList />}
//               </Paper>
//             </Grid>
//             <Grid item sm={9}>
//               <Paper className="cs142-main-grid-item">
//                 <Switch>
//                   <Route
//                     exact
//                     path="/login"
//                     render={(props) => <LoginRegister {...props} setUser={this.setUser} />}
//                   />
//                   <Route
//                     path="/users/:userId"
//                     render={(props) =>
//                       user ? <UserDetail {...props} /> : <Redirect to="/login" />
//                     }
//                   />
//                   <Route
//                     path="/photos/:userId"
//                     render={(props) =>
//                       user ? <UserPhotos {...props} advancedFeaturesEnabled={advancedFeaturesEnabled} /> : <Redirect to="/login" />
//                     }
//                   />
//                   <Route
//                     path="/users"
//                     render={() => (user ? <UserList /> : <Redirect to="/login" />)}
//                   />
//                   <Route
//                     exact
//                     path="/"
//                     render={() => (
//                       user ? (
//                         <Typography variant="body1">
//                           Welcome to your photosharing app! This <a href="https://mui.com/components/paper/">Paper</a> component displays the main content of the application. The {"sm={9}"} prop in the <a href="https://mui.com/components/grid/">Grid</a> item component makes it responsively display 9/12 of the window. The Switch component enables us to conditionally render different components to this part of the screen. You don&apos;t need to display anything here on the homepage, so you should delete this Route component once you get started.
//                         </Typography>
//                       ) : <Redirect to="/login" />
//                     )}
//                   />
//                   <Redirect to="/login" />
//                 </Switch>
//               </Paper>
//             </Grid>
//           </Grid>
//         </div>
//       </HashRouter>
//     );
//   }
// }
// ReactDOM.render(<PhotoShare />, document.getElementById("photoshareapp"));

import React from "react";
import ReactDOM from "react-dom";
import { Grid, Typography, Paper } from "@mui/material";
import { HashRouter, Route, Switch, Redirect } from "react-router-dom";

import "./styles/main.css";
import TopBar from "./components/TopBar";
import UserDetail from "./components/UserDetail";
import UserList from "./components/UserList";
import UserPhotos from "./components/UserPhotos";
import LoginRegister from "./components/loginRegister";

class PhotoShare extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      advancedFeaturesEnabled: false,
      user: JSON.parse(localStorage.getItem('user')),
    };
  }

  setUser = (user) => {
    this.setState({ user });
  };

  handleAdvancedFeaturesToggle = () => {
    this.setState((prevState) => ({
      advancedFeaturesEnabled: !prevState.advancedFeaturesEnabled,
    }));
  };

  render() {
    const { advancedFeaturesEnabled, user } = this.state;

    return (
      <HashRouter>
        <div>
          <Grid container spacing={2}>
            <Grid item xs={12}>
              <TopBar
                user={user}
                advancedFeaturesEnabled={advancedFeaturesEnabled}
                onAdvancedFeaturesToggle={this.handleAdvancedFeaturesToggle}
                setUser={this.setUser}
              />
            </Grid>
            <div className="cs142-main-topbar-buffer" />
            {user && (
              <Grid item sm={3}>
                <Paper className="cs142-main-grid-item">
                  <UserList />
                </Paper>
              </Grid>
            )}
            <Grid item sm={user ? 9 : 12}>
              <Paper className="cs142-main-grid-item">
                <Switch>
                  <Route
                    exact
                    path="/login"
                    render={(props) => <LoginRegister {...props} setUser={this.setUser} />}
                  />
                  <Route
                    path="/users/:userId"
                    render={(props) =>
                      user ? <UserDetail {...props} /> : <Redirect to="/login" />
                    }
                  />
                  <Route
                    path="/photos/:userId"
                    render={(props) =>
                      user ? <UserPhotos {...props} advancedFeaturesEnabled={advancedFeaturesEnabled} /> : <Redirect to="/login" />
                    }
                  />
                  <Route
                    path="/users"
                    render={() => (user ? <UserList /> : <Redirect to="/login" />)}
                  />
                  <Route
                    exact
                    path="/"
                    render={() => (
                      user ? (
                        <Typography variant="body1">
                          Welcome to your photosharing app! This <a href="https://mui.com/components/paper/">Paper</a> component displays the main content of the application. The {"sm={9}"} prop in the <a href="https://mui.com/components/grid/">Grid</a> item component makes it responsively display 9/12 of the window. The Switch component enables us to conditionally render different components to this part of the screen. You don&apos;t need to display anything here on the homepage, so you should delete this Route component once you get started.
                        </Typography>
                      ) : <Redirect to="/login" />
                    )}
                  />
                  <Redirect to="/login" />
                </Switch>
              </Paper>
            </Grid>
          </Grid>
        </div>
      </HashRouter>
    );
  }
}

ReactDOM.render(<PhotoShare />, document.getElementById("photoshareapp"));
